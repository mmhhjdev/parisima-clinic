import React from 'react';
import { useI18n } from '../i18n/LanguageProvider';
import { assetUrl } from '../lib/assets';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  textColor?: 'dark' | 'light';
  showSubtitle?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ size = 'md', textColor = 'dark', showSubtitle = true }) => {
  const { t } = useI18n();
  const isDark = textColor === 'dark';
  const iconSizes = { sm: 'w-8 h-8', md: 'w-10 h-10', lg: 'w-12 h-12' };
  const titleSizes = { sm: 'text-base', md: 'text-lg sm:text-xl', lg: 'text-2xl sm:text-3xl' };
  const subtitleSizes = { sm: 'text-[10px]', md: 'text-[11px]', lg: 'text-xs' };

  return (
    <div className="flex items-center gap-2.5 select-none">
      <img src={assetUrl('logo.png')} alt={t('logo.alt')} className={`${iconSizes[size]} object-contain flex-shrink-0`} />
      <div className="flex flex-col text-start">
        <span className={`font-header font-black leading-tight ${titleSizes[size]} ${isDark ? 'text-[#0F172A]' : 'text-white'}`}>
          {t('logo.name1')}{' '}
          <span className="font-header font-black text-[#0369A1]">{t('logo.name2')}</span>
        </span>
        {showSubtitle && (
          <span className={`font-header font-bold ${subtitleSizes[size]} ${isDark ? 'text-slate-500' : 'text-slate-300'} mt-0.5`}>
            {t('logo.sub')}
          </span>
        )}
      </div>
    </div>
  );
};

export default Logo;
