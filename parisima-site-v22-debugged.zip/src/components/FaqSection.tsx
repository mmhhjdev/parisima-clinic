import React, { useState } from 'react';
import { HelpCircle, ChevronDown } from 'lucide-react';
import { useI18n } from '../i18n/LanguageProvider';

export const FaqSection: React.FC = () => {
  const { t, content } = useI18n();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="py-16 sm:py-20 bg-[#F8FAFC] border-b border-slate-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0369A1] bg-[#F0F9FF] px-3 py-1 rounded-full border border-[#BAE6FD] mb-3">
            <HelpCircle className="w-3.5 h-3.5 text-[#0369A1]" />
            <span className="font-header">{t('faq.badge')}</span>
          </div>
          <h2 className="font-header text-2xl sm:text-3xl font-black text-[#0F172A] tracking-tight">{t('faq.title')}</h2>
          <p className="font-sans text-sm text-slate-500 mt-2">{t('faq.subtitle')}</p>
        </div>

        <div className="space-y-3">
          {content.faqs.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div key={item.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden transition-all shadow-2xs">
                <button
                  type="button"
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  aria-expanded={isOpen}
                  className="w-full p-4 sm:p-5 flex items-center justify-between gap-4 text-start hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  <span className="font-header text-xs sm:text-sm font-bold text-[#0F172A]">{item.question}</span>
                  <ChevronDown className={`w-4 h-4 text-[#0369A1] flex-shrink-0 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
                </button>
                {isOpen && (
                  <div className="font-sans px-4 pb-5 sm:px-5 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default FaqSection;
