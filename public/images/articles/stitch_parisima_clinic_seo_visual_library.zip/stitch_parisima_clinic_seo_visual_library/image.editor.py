from pathlib import Path
from PIL import Image, ImageOps

# تنظیمات بهینه‌سازی برای وب
TARGET_FILENAME = "screen.png"
OUTPUT_NAME = "screen.webp"
MAX_WIDTH = 1600  # حداکثر عرض تصویر (اگر بزرگ‌تر باشد متناسب کوچک می‌شود)
QUALITY = 82  # کیفیت WebP بین 0 تا 100
DELETE_ORIGINAL_PNG = True  # True = حذف screen.png پس از ساخت موفق screen.webp
DRY_RUN = False  # True = فقط شبیه‌سازی و نمایش، بدون حذف واقعی فایل‌ها


def format_size(num_bytes: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if num_bytes < 1024:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024
    return f"{num_bytes:.1f} TB"


def optimize_png_to_webp(root_dir: Path) -> None:
    converted_count = 0
    deleted_count = 0
    total_original_size = 0
    total_webp_size = 0

    # جستجو در تمام زیرپوشه‌ها برای پیدا کردن screen.png
    for png_path in sorted(root_dir.rglob(TARGET_FILENAME)):
        if not png_path.is_file():
            continue

        webp_path = png_path.with_name(OUTPUT_NAME)
        orig_size = png_path.stat().st_size

        try:
            with Image.open(png_path) as img:
                # اصلاح جهت تصویر بر اساس متادیتای EXIF در صورت وجود
                img = ImageOps.exif_transpose(img)

                # تبدیل حالت رنگ برای حفظ شفافیت (Alpha) یا سازگاری با WebP
                if img.mode in ("RGBA", "LA"):
                    img = img.convert("RGBA")
                elif img.mode == "P":
                    img = img.convert("RGBA" if "transparency" in img.info else "RGB")
                else:
                    img = img.convert("RGB")

                # کوچک‌سازی هوشمند اگر عرض تصویر بیشتر از MAX_WIDTH باشد
                if MAX_WIDTH and img.width > MAX_WIDTH:
                    ratio = MAX_WIDTH / img.width
                    new_height = int(img.height * ratio)
                    img = img.resize((MAX_WIDTH, new_height), Image.Resampling.LANCZOS)

                # ذخیره به صورت WebP بهینه
                if not DRY_RUN:
                    img.save(
                        webp_path,
                        format="WEBP",
                        quality=QUALITY,
                        method=6,
                    )

            # محاسبه حجم خروجی (در حالت DRY_RUN حجم تخمینی نمایش داده می‌شود)
            if DRY_RUN:
                new_size = 0
                saved_text = "حالت آزمایشی (DRY_RUN)"
            else:
                if not webp_path.exists() or webp_path.stat().st_size == 0:
                    raise RuntimeError("فایل خروجی WebP ساخته نشد یا خالی است.")

                new_size = webp_path.stat().st_size
                saved_percent = ((orig_size - new_size) / orig_size * 100) if orig_size > 0 else 0
                saved_text = f"{saved_percent:.1f}% کاهش حجم"

            converted_count += 1
            total_original_size += orig_size
            total_webp_size += new_size

            delete_status = ""
            if DELETE_ORIGINAL_PNG:
                if DRY_RUN:
                    delete_status = " | [DRY_RUN] آماده حذف PNG"
                else:
                    png_path.unlink()
                    deleted_count += 1
                    delete_status = " | PNG حذف شد"

            print(
                f"[OK] {png_path.parent.name}/{OUTPUT_NAME} | "
                f"{format_size(orig_size)} -> {format_size(new_size)} ({saved_text}){delete_status}"
            )

        except Exception as e:
            print(f"[ERR] خطا در پردازش {png_path}: {e}")

    print("-" * 65)
    print(f"تعداد فایل‌های پردازش‌شده: {converted_count}")
    print(f"تعداد فایل‌های PNG حذف‌شده: {deleted_count}")
    print(f"حجم کل اولیه (PNG): {format_size(total_original_size)}")
    if not DRY_RUN:
        print(f"حجم کل جدید (WebP): {format_size(total_webp_size)}")
        if total_original_size > 0:
            total_saved = (total_original_size - total_webp_size) / total_original_size * 100
            print(f"مجموع کاهش حجم: {total_saved:.1f}%")


if __name__ == "__main__":
    script_root = Path(__file__).resolve().parent
    optimize_png_to_webp(script_root)